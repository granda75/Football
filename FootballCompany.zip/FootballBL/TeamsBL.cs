﻿using Football.DAL;
using Football.DAL.Repository;
using System;
using System.Collections.Generic;

namespace FootballBL
{
    public class TeamsBL
    {
        #region Fields

        private TeamsRepository _repoTeamsPlayers;

        #endregion

        #region Constructors

        public TeamsBL()
        {
            _repoTeamsPlayers = new TeamsRepository();
        }

        #endregion

        #region Public methods

        public TeamCard Login(string email, string password)
        {
            string passwordHashed = PasswordUtil.GetMD5Hash(password);
            TeamCard team = _repoTeamsPlayers.Login(email, passwordHashed);
            return team;
        }

        public TeamCard CheckTeamCredentials(string email, string password)
        {
           string encodedPassword = PasswordUtil.GetMD5Hash(password);
           TeamCard team = _repoTeamsPlayers.CheckTeamCredentials(email, encodedPassword);
            return team;
        }

        public List<TeamCard> GetAllTeams()
        {
            return _repoTeamsPlayers.GetAllTeams();
        }

        public void AddNewTeam(TeamCard team)
        {
            team.TeamGuid = Guid.NewGuid();
            team.Password = PasswordUtil.GetMD5Hash(team.Password);
            _repoTeamsPlayers.AddNewTeam(team);
        }

        public void DeleteTeam(TeamCard team)
        {
            _repoTeamsPlayers.DeleteTeam(team);
        }

        public Response UpdateTeam(TeamCard team)
        {
            team.Password = PasswordUtil.GetMD5Hash(team.Password);
            return _repoTeamsPlayers.UpdateTeam(team);
        }

        #endregion
    }
}
