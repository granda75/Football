﻿using Football.DAL;
using Football.DAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FootballBL
{
    public class TransferTransactionsBL
    {
        #region Fields

        private TransferTransactionRepository _repoTransfers;
        private PlayersRepository _repoPlayers;

        #endregion

        #region Constructors

        public TransferTransactionsBL()
        {
            _repoTransfers = new TransferTransactionRepository();
            _repoPlayers = new PlayersRepository();
        }

        #endregion

        #region Public methods

        public List<TransferPlayersDetails> GetTransferTransactionsData(DateTime selectedDate)
        {
            List<TransferPlayersDetails> lstPlayers = _repoTransfers.GetTransferTransactionsData().Where(l=>l.TransferDate.Date == selectedDate.Date).ToList();
            return lstPlayers;
        }

        public List<TransferPlayersDetails> GetTransferTransactionsData(string teamName)
        {
            //return _repoTransfers.GetTransferTransactionsData(teamName).ToList();
            List<TransferPlayersDetails> lstPlayers = _repoTransfers.GetTransferTransactionsData().Where(l => l.TargetTeam == teamName).ToList();
            return lstPlayers;
        }

        public void FillTransferState()
        {
            _repoTransfers.FillTransferState();
        }

        public void GetTransactionsByTeam(string teamName)
        {
            _repoTransfers.GetTransactionsByTeam(teamName);
        }

        public void AddTransferTransaction(TransferTransaction trans)
        {
            _repoPlayers.UpdatePlayersTeam(trans);
             _repoTransfers.AddTransferTransaction(trans);
        }

        public List<TransferTransaction> GetAllTransferTransactions()
        {
            return _repoTransfers.GetAllTransferTransactions();
        }

        public List<TransferState> GetAllTransferStates()
        {
            return _repoTransfers.GetAllTransferStates();
        }

        #endregion
    }
}
