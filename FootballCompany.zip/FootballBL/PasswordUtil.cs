﻿using System;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace FootballBL
{
    public static class PasswordUtil
    {

        #region Public methods

        public static string GetMD5Hash(string original)
        {
            byte[] ByteRepresentation = UnicodeEncoding.UTF8.GetBytes(original);
            byte[] HashedTextInBytes = null;
            MD5CryptoServiceProvider myMD5 = new MD5CryptoServiceProvider();
            HashedTextInBytes = myMD5.ComputeHash(ByteRepresentation);

            return Convert.ToBase64String(HashedTextInBytes);
        }

        public static bool ValidatePassword(string password)
        {
            //string Pattern = @"(?=^.{8,32}$)(?=.*\d)(?=^[a-zA-Z])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_\-+}{"":;'?/>.<,]).*$";
            string Pattern = @"^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,32}$";

            if (password.Length < 8 || password.Length > 32 || !Regex.Match(password, Pattern).Success)
            {
                return false;
            }

            return true;
        }

        public static string EncodePasswordToBase64(string password)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(password);
            byte[] inArray = HashAlgorithm.Create("SHA1").ComputeHash(bytes);
            return Convert.ToBase64String(inArray);
        }


        #endregion
    }

}
