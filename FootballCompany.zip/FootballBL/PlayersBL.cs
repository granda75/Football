﻿using Football.DAL;
using Football.DAL.Repository;
using System;
using System.Collections.Generic;


namespace FootballBL
{
    public class PlayersBL
    {
        #region Fields

        private PlayersRepository _repoPlayers;

        #endregion

        #region Constructors

        public PlayersBL()
        {
            _repoPlayers = new PlayersRepository();
        }

        #endregion

        #region Public methods

        public void FillPlayerStatuses()
        {
            _repoPlayers.FillPlayerStatuses();
        }

        public List<PlayerCard> GetPlayersByTeam(string team)
        {
            return _repoPlayers.GetPlayersByTeam(team);
        }

        public List<PlayerCard> GetPlayerCards()
        {
            return _repoPlayers.GetAllPlayers();
        }

        public void ActivatePlayer(PlayerCard player)
        {
            _repoPlayers.ActivatePlayer(player);
        }

        public void ReleasePlayer(PlayerCard player)
        {
            _repoPlayers.ReleasePlayer(player);
        }


        public Response UpdatePlayer(PlayerCard player)
        {
             return _repoPlayers.UpdatePlayer(player);
        }

        public void RetirePlayer(PlayerCard player)
        {
            _repoPlayers.RetirePlayer(player);
        }


        public void CreateNewPlayer(PlayerCard player)
        {
            player.PlayerGUID = Guid.NewGuid();
            _repoPlayers.CreateNewPlayer(player);
        }

        #endregion
    }
}
