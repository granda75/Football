﻿using Football.DAL;
using FootballCompany.AccountServiceRef;
using System;


namespace FootballCompany
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            AccountServiceClient client = new AccountServiceClient();

            TeamCard team = client.LogOn(txtUserName.Text, txtPassword.Text);
            Session["UsersTeam"] = team;
            if (team == null)
            {
                lblErrorMessage.Text = "The username or password is not right, please insert once more !";
            }
            else
            {
                Response.Redirect("~/Default.aspx");
            }
        }
    }
}