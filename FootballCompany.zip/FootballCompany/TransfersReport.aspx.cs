﻿using Football.DAL;
using FootballCompany.TeamServiceRef;
using FootballCompany.TransferServiceRef;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FootballCompany
{
    public partial class TransfersReport : System.Web.UI.Page
    {
        #region Fields

        private TransferServiceClient _transfersWcf;
        private TeamsServiceClient _wcfTeams;

        #endregion

        #region Methods

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                _wcfTeams = new TeamsServiceClient();
                List<TeamCard> lstTeams = _wcfTeams.GetAllTeams().ToList<TeamCard>();
                this.ddlTeams.DataSource = lstTeams;
                ddlTeams.DataBind();
                Session["AllTeams"] = lstTeams;

            }
        }

        protected void btnGetTransfer_Click(object sender, EventArgs e)
        {
            string teamName = ddlTeams.Text;
            _transfersWcf = new TransferServiceClient();
            List<TransferPlayersDetails> lst = _transfersWcf.GetTransferTransactionsByTeam(teamName).ToList<TransferPlayersDetails>();
            gridTransfers.DataSource = lst;
            gridTransfers.DataBind();
        }

        protected void btnGetTransferByDate_Click(object sender, EventArgs e)
        {
            DateTime date= (DateTime) Session["ReportsDate"];
            _transfersWcf = new TransferServiceClient();
            List<TransferPlayersDetails> lst =  _transfersWcf.GetTransferTransactionsByDate(date).ToList<TransferPlayersDetails>();
            gridTransfers.DataSource = lst;
            gridTransfers.DataBind();
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            Session["ReportsDate"] = Calendar1.SelectedDate;
           
        }

        #endregion
    }
}