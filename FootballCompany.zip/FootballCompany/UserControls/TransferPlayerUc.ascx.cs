﻿using Football.DAL;
using FootballCompany.TransferServiceRef;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace FootballCompany.UserControls
{
    public partial class TransferPlayerUc : System.Web.UI.UserControl
    {
        #region Methods

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                List<TeamCard> lstTeams = (List<TeamCard>)Session["AllTeams"];
                this.ddlTargetTeam.DataSource = lstTeams;
                this.ddlTargetTeam.DataBind();
            }
            GridViewRow row = (GridViewRow)Session["PlayerSelectedRow"];

            if (row != null)
            {
                this.txtPlayerId.Text = row.Cells[2].Text;

                this.txtPlayerGuid.Text = row.Cells[3].Text;
                this.txtFirstName.Text = row.Cells[4].Text;
                this.txtLastName.Text = row.Cells[5].Text;
                this.txtMarketingValue.Text = row.Cells[7].Text;
                this.txtCurrentTeam.Text = row.Cells[8].Text;
                this.lblErrorMessage.Text = String.Empty;
            }
        }

        protected void btnTransferPlayer_Click1(object sender, EventArgs e)
        {
            TransferServiceClient client = new TransferServiceClient();
            TransferTransaction transaction = new TransferTransaction();
            transaction.ParentTeam = txtCurrentTeam.Text;
            transaction.TargetTeam = ddlTargetTeam.Text;
            transaction.TransferValue = 1;
            transaction.PlayerId = Convert.ToInt32(txtPlayerId.Text);
            transaction.TransferDate = DateTime.Now;

            TeamCard currentTeam = (TeamCard)Session["UsersTeam"];
            if (currentTeam != null && currentTeam.TeamName == transaction.ParentTeam)
            {
                client.AddTransferTransaction(transaction);

                ClearAllFields();
                this.Visible = false;
                ((PlayersManagement)this.Page).GetPlayersAndBindGrid();
                ((PlayersManagement)this.Page).SetAddTeamButtonVisible();
                this.Visible = false;
            }
            else
            {
                this.lblErrorMessage.Text = "You don't have permissions insert the player to another team ! Please change the team and try again.";
            }

            
        }

        private void ClearAllFields()
        {
            txtPlayerGuid.Text = String.Empty;
            txtPlayerId.Text = String.Empty;
            txtFirstName.Text = String.Empty;
            txtLastName.Text = String.Empty;
            txtMarketingValue.Text = String.Empty;
            txtCurrentTeam.Text = String.Empty;
            ddlTargetTeam.SelectedIndex = -1;
        }

        #endregion
    }
}