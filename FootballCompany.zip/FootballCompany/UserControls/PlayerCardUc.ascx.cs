﻿using Football.DAL;
using FootballCompany.PlayersServiceRef;
using System;

namespace FootballCompany.UserControls
{
    public partial class PlayerCardUc : System.Web.UI.UserControl
    {
        #region Fields

        private PlayersServiceClient _client;

        #endregion

        #region Methods

        protected void Page_Load(object sender, EventArgs e)
        {
            this.lblErrorMessage.Text = String.Empty;
        }
       
        protected void btnSave_Click1(object sender, EventArgs e)
        {
            _client = new PlayersServiceClient();

            PlayerCard player = new PlayerCard();
            player.PlayerGUID = Guid.NewGuid();
            player.FirstName = txtFirstName.Text;
            player.LastName = txtLastName.Text;
            player.Position = txtPosition.Text;
            player.MarketingValue = Convert.ToDecimal( txtMarketValue.Text);
            player.CurrentTeam = txtCurrentTeam.Text;
            player.PreviousTeam = txtPrevTeam.Text;
            if (!string.IsNullOrEmpty(txtLastTransferTrans.Text))
            {
                player.LastTransferTransaction = Convert.ToInt32(txtLastTransferTrans.Text);
            }
            player.PlayerStatus = (int)PlayerStatusEnum.Active;

            TeamCard currentTeam = (TeamCard)Session["UsersTeam"];
            if (currentTeam != null && currentTeam.TeamName == player.CurrentTeam)
            {
                _client.CreateNewPlayer(player);

                ClearAllFields();
                this.Visible = false;
                ((PlayersManagement)this.Page).GetPlayersAndBindGrid();
                ((PlayersManagement)this.Page).SetAddTeamButtonVisible();
            }
            else
            {
                this.lblErrorMessage.Text = "You don't have permissions insert the player to another team ! Please change team and try again.";
            }
            
        }

        private void ClearAllFields()
        {
            txtFirstName.Text = String.Empty;
            txtLastName.Text = String.Empty;
            txtPosition.Text = String.Empty;
            txtMarketValue.Text = String.Empty;
            txtCurrentTeam.Text = String.Empty;
            txtPrevTeam.Text = String.Empty;
            txtLastTransferTrans.Text = String.Empty;

        }
        #endregion
    }
}