﻿using Football.DAL;
using FootballCompany.TeamServiceRef;
using System;


namespace FootballCompany.UserControls
{
    public partial class TeamCardUc : System.Web.UI.UserControl
    {
        #region Fields

        private TeamsServiceClient _teamClient;

        #endregion

        #region Methods

        public void ClearAllFields()
        {
            txtMainColor.Text = String.Empty;
            txtSecondaryColor.Text = String.Empty;
            txtPassword.Text = String.Empty;
            txtTeamBudget.Text = String.Empty;
            txtTeamCity.Text = String.Empty;
            txtTeamLogoName.Text = String.Empty;
            txtTeamName.Text = String.Empty;
            txtTeamSquad.Text = String.Empty;
            txtUserName.Text = String.Empty;
        }


        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            _teamClient = new TeamsServiceClient();
            TeamCard team = new TeamCard();
            team.TeamName = txtTeamName.Text;
            team.Password = txtPassword.Text;
            team.MainColor = txtMainColor.Text;
            team.SecondaryColor = txtSecondaryColor.Text;
            team.TeamLogoName = txtTeamLogoName.Text;
            team.TeamCity = txtTeamCity.Text;
            team.TeamSquad = txtTeamSquad.Text;
            team.TeamBudget = Convert.ToDecimal(txtTeamBudget.Text);
            team.TeamManagerEmail = txtUserName.Text;


            Response response = _teamClient.AddNewTeam(team);
            if (response != null && !string.IsNullOrEmpty(response.ErrorMessage))
            {
                lblErrorMessage.Text = response.ErrorMessage;
            }
            else
            {
                ClearAllFields();
                this.Visible = false;
                ((TeamsManagement)this.Page).GetTeamsDataAndBindGrid();
                ((TeamsManagement)this.Page).SetAddTeamButtonVisible();
            }

            #endregion

        }
    }
}