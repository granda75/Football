﻿
function ValidateAddNewPlayer() {
    debugger;

    var firstName = document.getElementById("MainContent_PlayerCardUc_txtFirstName").value;
    if (!firstName) {
        document.getElementById("MainContent_PlayerCardUc_lblErrorMessage").innerHTML = "Please enter first name!";
        return false;
    }

    var lastName = document.getElementById("MainContent_PlayerCardUc_txtLastName").value;
    if (!lastName) {
        document.getElementById("MainContent_PlayerCardUc_lblErrorMessage").innerHTML = "Please enter last name!";
        return false;
    }

    var currentTeam = document.getElementById("MainContent_PlayerCardUc_txtCurrentTeam").value;
    if (!currentTeam) {
        document.getElementById("MainContent_PlayerCardUc_lblErrorMessage").innerHTML = "Please enter current team!";
        return false;
    }

    var prevTeam = document.getElementById("MainContent_PlayerCardUc_txtPrevTeam").value;
    if (!prevTeam)
    {
        document.getElementById("MainContent_PlayerCardUc_lblErrorMessage").innerHTML = "Please enter previous team!";
        return false;
    }

    var lastTrans = document.getElementById("MainContent_PlayerCardUc_txtLastTransferTrans").value;
    if (!lastTrans) {
        document.getElementById("MainContent_PlayerCardUc_lblErrorMessage").innerHTML = "Please enter last transfer transaction!";
        return false;
    }

    
 


}