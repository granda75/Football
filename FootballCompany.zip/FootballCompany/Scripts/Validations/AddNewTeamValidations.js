﻿
function ValidateAddNewTeam()
{
    debugger;

    var teamName = document.getElementById("MainContent_TeamCardUc1_txtTeamName").value;
    if (!teamName)
    {
        document.getElementById("MainContent_TeamCardUc1_lblErrorMessage").innerHTML = "Please enter team name!";
        return false;
    }

    var teamBudget = document.getElementById("MainContent_TeamCardUc1_txtTeamBudget").value;
    if (!teamBudget) {
        document.getElementById("MainContent_TeamCardUc1_lblErrorMessage").innerHTML = "Please enter team budget!";
        return false;
    }
    
    var teamSquad = document.getElementById("MainContent_TeamCardUc1_txtTeamSquad").value;
    if (!teamSquad) {
        document.getElementById("MainContent_TeamCardUc1_lblErrorMessage").innerHTML = "Please enter team squad!";
        return false;
    }

    var email = document.getElementById("MainContent_TeamCardUc1_txtUserName").value;
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
    {
        var password = document.getElementById("MainContent_TeamCardUc1_txtPassword").value;
        if ( /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/.test(password) )
        {
            return true;
        }
        else
        {
            document.getElementById("MainContent_TeamCardUc1_lblErrorMessage").innerHTML = "You have entered an invalid password!";
            return false;
        }
        return true;
    }
    else
    {
        document.getElementById("MainContent_TeamCardUc1_lblErrorMessage").innerHTML = "You have entered an invalid email address!";
        return false;
    }

    
}