﻿using Football.DAL;
using FootballCompany.TeamServiceRef;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services.Description;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FootballCompany
{
    public partial class TeamsManagement : Page
    {
        #region Fields

        private List<TeamCard> _teamCards;
        private TeamsServiceClient _teamClient;

        #endregion

        #region Constructor

        public TeamsManagement()
        {
            _teamClient = new TeamsServiceClient();
        }

        #endregion

        #region Methods

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                _teamCards = _teamClient.GetAllTeams().ToList<TeamCard>();
                Session["Teams"] = _teamCards;
                this.GridDataBind();
                this.TeamCardUc1.Visible = false;
            }
        }

        public void SetAddTeamButtonVisible()
        {
            this.btnAddTeam.Visible = true;
        }

        public void GetTeamsDataAndBindGrid() 
        {
            Session["Teams"] = _teamClient.GetAllTeams().ToList<TeamCard>();
            this.GridDataBind();
        }

        public void GridDataBind()
        {
            this.TeamsGrid.DataSource = (List<TeamCard>)Session["Teams"];
            this.TeamsGrid.DataBind();
        }

        protected void TeamsGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string item = e.Row.Cells[0].Text;
                foreach (Button button in e.Row.Cells[2].Controls.OfType<Button>())
                {
                    if (button.CommandName == "Delete")
                    {
                        button.Attributes["onclick"] = "if(!confirm('Do you want to delete " + item + "?')){ return false; };";
                    }
                }
            }
        }

        protected void TeamsGrid_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int index = Convert.ToInt32(e.RowIndex);
            _teamCards = (List<TeamCard>)Session["Teams"];
            TeamCard cardToDelete = _teamCards[index];
            TeamCard currentTeam = (TeamCard)Session["UsersTeam"];
            if (currentTeam != null && currentTeam.TeamName == cardToDelete.TeamName)
            {
                _teamClient.DeleteTeam(cardToDelete);
            }
            else
            {
                lblErrorMessage.Text = "You can delete only your team !";
            }

            GetTeamsDataAndBindGrid();
        }

        protected void TeamsGrid_RowEditing(object sender, GridViewEditEventArgs e)
        {
            TeamsGrid.EditIndex = e.NewEditIndex;
            _teamCards = (List<TeamCard>)Session["Teams"];
            GridDataBind();
        }

        protected void TeamsGrid_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            TeamCard team = new TeamCard();

            team.TeamId = Convert.ToInt32(((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[1].Controls[0]).Text);
            team.TeamGuid = Guid.Parse(((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[2].Controls[0]).Text);
            team.TeamName = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[3].Controls[0]).Text;
            team.MainColor = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[4].Controls[0]).Text;
            team.SecondaryColor = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[5].Controls[0]).Text;
            team.TeamLogoName = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[6].Controls[0]).Text;
            team.TeamCity = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[7].Controls[0]).Text;
            team.TeamSquad = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[8].Controls[0]).Text;

            string gridsBudget = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[9].Controls[0]).Text;
            if ( !string.IsNullOrEmpty(gridsBudget) )
            {
                decimal result;
                decimal.TryParse(gridsBudget, out result);
                team.TeamBudget = result;
                
            }
            team.TeamManagerEmail = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[10].Controls[0]).Text;
            team.Password  = ((TextBox)(TeamsGrid.Rows[TeamsGrid.EditIndex]).Cells[11].Controls[0]).Text;

            TeamCard currentTeam = (TeamCard)Session["UsersTeam"];
            if (currentTeam != null && currentTeam.TeamName == team.TeamName )
            { 
                Response response = _teamClient.UpdateTeam(team);
                if (response != null && !string.IsNullOrEmpty(response.ErrorMessage))
                {
                    lblErrorMessage.Text = response.ErrorMessage;
                }
                else 
                {
                    lblErrorMessage.Text = String.Empty;
                }
            }
            else
            {
                lblErrorMessage.Text = "You can update only your team !";
            }
            
            this.TeamsGrid.EditIndex = -1;
            GetTeamsDataAndBindGrid();
        }

        protected void btnAddTeam_Click(object sender, EventArgs e)
        {
            this.TeamCardUc1.Visible = true;
            this.btnAddTeam.Visible = false;
        }

        protected void TeamsGrid_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            // Retrieve the row that raised the event from the Rows
            // collection of the GridView control.
            GridViewRow row = TeamsGrid.Rows[e.RowIndex];

            // The update operation was canceled. Display the 
            // primary key of the row. In this example, the primary
            // key is displayed in the second column of the GridView
            // control. To access the text of the column, use the Cells
            // collection of the row.
            string updateText = "Update for item " + row.Cells[1].Text + " Canceled.";
        }

        #endregion
    }
}