﻿using Football.DAL;
using FootballCompany.PlayersServiceRef;
using FootballCompany.TeamServiceRef;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FootballCompany
{
    public partial class PlayersManagement : Page
    {
        #region Fields

        private PlayersServiceClient _wcfPlayers;
        private TeamsServiceClient   _wcfTeams;
        private List<PlayerCard> _players;

        #endregion

        #region Methods

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                _wcfTeams = new TeamsServiceClient();
                List<TeamCard> lstTeams = _wcfTeams.GetAllTeams().ToList<TeamCard>();
                this.teamsDDL.DataSource = lstTeams;
                teamsDDL.DataBind();
                Session["AllTeams"] = lstTeams;

                this.PlayerCardUc.Visible = false;
                this.TransferPlayerUc.Visible = false;

            }
          }

        protected void btnGetPlayers_Click(object sender, EventArgs e)
        {
            _wcfPlayers = new PlayersServiceClient();
            List<PlayerCard> players = _wcfPlayers.GetPlayersByTeam(teamsDDL.Text).ToList();
            Session["PlayersByTeam"] = players;
            this.PlayerCardUc.Visible = false;
            this.TransferPlayerUc.Visible = false;
            this.lblErrorMessage.Text = String.Empty;

            BindGrid();
        }

        protected void playersGrid_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedRow     = playersGrid.SelectedIndex;
            Session["PlayerSelectedRow"] = playersGrid.Rows[selectedRow];
        }

        public void GetPlayersAndBindGrid()
        {
            _wcfPlayers = new PlayersServiceClient();
            _players = _wcfPlayers.GetPlayersByTeam(teamsDDL.Text).ToList();
            this.GridDataBind();
        }

        public void GridDataBind()
        {
            this.playersGrid.DataSource = _players;
            this.playersGrid.DataBind();
        }

        public void BindGrid()
        {
            List<PlayerCard> players = (List<PlayerCard>)Session["PlayersByTeam"]; 
            playersGrid.DataSource = players;
            playersGrid.DataBind();
        }

        public void SetAddTeamButtonVisible()
        {
            this.btnAddPlayer.Visible = true;
        }

        protected void playersGrid_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            GridViewRow row = playersGrid.Rows[e.NewEditIndex];
            string currentTeam = row.Cells[8].Text;
            Session["CurrentRowTeam"] = currentTeam;

            // Set the edit index.
            playersGrid.EditIndex = e.NewEditIndex;
            //Bind data to the GridView control.
            BindGrid();
        }

        protected void playersGrid_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            List<PlayerCard> players = (List<PlayerCard>)Session["PlayersByTeam"];
            GridViewRow row = playersGrid.Rows[e.RowIndex];

            PlayerCard player = new PlayerCard();
            player.PlayerId = Convert.ToInt32(((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[2].Controls[0]).Text);
            player.PlayerGUID = Guid.Parse(((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[3].Controls[0]).Text);
            player.FirstName = ((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[4].Controls[0]).Text;
            player.LastName = ((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[5].Controls[0]).Text;
            player.Position = ((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[6].Controls[0]).Text;
            player.MarketingValue = Convert.ToDecimal(((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[7].Controls[0]).Text);
            player.CurrentTeam = ((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[8].Controls[0]).Text;
            player.PreviousTeam = ((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[9].Controls[0]).Text;
            player.LastTransferTransaction = Convert.ToInt32(((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[10].Controls[0]).Text);
            player.PlayerStatus = Convert.ToInt32(((TextBox)(playersGrid.Rows[playersGrid.EditIndex]).Cells[11].Controls[0]).Text);
            //player.PlayerStatus = (!string.IsNullOrEmpty(row.Cells[11].Text))? Convert.ToInt32(row.Cells[11].Text) : 0;

            players[row.DataItemIndex] = player;

            _wcfPlayers = new PlayersServiceClient();

            TeamCard usersTeam = (TeamCard)Session["UsersTeam"];
            if (usersTeam != null && usersTeam.TeamName == (string)Session["CurrentRowTeam"])
            {
                Response response = _wcfPlayers.UpdatePlayer(player);
                if (response != null && !string.IsNullOrEmpty(response.ErrorMessage))
                {
                    lblErrorMessage.Text = response.ErrorMessage;
                }
            }
            else
            {
                lblErrorMessage.Text = "You can update only players from your team !";
            }

            //Setting the EditIndex property to -1 to cancel the Edit mode in Gridview  
            this.playersGrid.EditIndex = -1;

            GetPlayersAndBindGrid();
        }

        protected void playersGrid_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            //Reset the edit index.
            playersGrid.EditIndex = -1;
            //Bind data to the GridView control.
            BindGrid();
        }

        protected void btnAddPlayer_Click(object sender, EventArgs e)
        {
            this.PlayerCardUc.Visible = true;
            //this.btnAddPlayer.Visible = false;
        }

        protected void btnTransfer_Click(object sender, EventArgs e)
        {
            this.TransferPlayerUc.Visible = true;
        }

        protected void btnRelease_Click(object sender, EventArgs e)
        {
            GridViewRow row = (GridViewRow)Session["PlayerSelectedRow"];
            PlayerCard player = new PlayerCard();

            _wcfPlayers = new PlayersServiceClient();
            if ( row != null )
            {
                player.PlayerId = Convert.ToInt32(row.Cells[2].Text);
                player.CurrentTeam = row.Cells[8].Text;
                player.PreviousTeam = row.Cells[9].Text;

                TeamCard currentTeam = (TeamCard)Session["UsersTeam"];
                if ( currentTeam != null && currentTeam.TeamName == player.CurrentTeam )
                {
                    _wcfPlayers.ReleasePlayer(player);
                }
                else
                {
                    this.lblErrorMessage.Text = "You don't have permissions to release the player of another team ! Please change the team and try again.";
                }

                GetPlayersAndBindGrid();
            }
        }

        protected void btnRetire_Click(object sender, EventArgs e)
        {
            GridViewRow row = (GridViewRow)Session["PlayerSelectedRow"];
            PlayerCard player = new PlayerCard();

            _wcfPlayers = new PlayersServiceClient();

            if (row != null)
            {
                player.PlayerId = Convert.ToInt32(row.Cells[2].Text);
                player.CurrentTeam = row.Cells[8].Text;
                player.PreviousTeam = row.Cells[9].Text;

                TeamCard currentTeam = (TeamCard)Session["UsersTeam"];
                if (currentTeam != null && currentTeam.TeamName == player.CurrentTeam)
                {
                    _wcfPlayers.RetirePlayer(player);
                }
                else
                {
                    this.lblErrorMessage.Text = "You don't have permissions to retire the player of another team ! Please change the team and try again.";
                }
                GetPlayersAndBindGrid();
            }
        }

        protected void btnActivate_Click(object sender, EventArgs e)
        {
            GridViewRow row = (GridViewRow)Session["PlayerSelectedRow"];
            PlayerCard player = new PlayerCard();

            _wcfPlayers = new PlayersServiceClient();

            if (row != null)
            {
                player.PlayerId = Convert.ToInt32(row.Cells[2].Text);
                player.CurrentTeam = row.Cells[8].Text;

                TeamCard currentTeam = (TeamCard)Session["UsersTeam"];
                if (currentTeam != null && currentTeam.TeamName == player.CurrentTeam)
                {
                    _wcfPlayers.ActivatePlayer(player);
                }
                else
                {
                    this.lblErrorMessage.Text = "You don't have permissions to activate the player of another team ! Please change the team and try again.";
                }
                GetPlayersAndBindGrid();
            }
        }

        #endregion
    }
}