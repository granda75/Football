﻿using Football.DAL;
using FootballBL;
using System;
using System.Collections.Generic;


public class TransferService : ITransferService
{
    #region Fields

    private TransferTransactionsBL _transferBL;

    #endregion

    #region Constructor

    public TransferService()
    {
        _transferBL = new TransferTransactionsBL();
    }

    #endregion

    #region Public methods

    public void FillTransferState()
    {
        _transferBL.FillTransferState();
    }

    public void AddTransferTransaction(TransferTransaction trans)
    {
        _transferBL.AddTransferTransaction(trans);
    }

    public List<TransferState> GetAllTransferStates()
    {
        return _transferBL.GetAllTransferStates();
    }

    public List<TransferTransaction> GetAllTransferTransactions()
    {
        return _transferBL.GetAllTransferTransactions();
    }


    public List<TransferPlayersDetails> GetTransferTransactionsByTeam(string teamName)
    {
         return _transferBL.GetTransferTransactionsData(teamName);
    }

    public List<TransferPlayersDetails> GetTransferTransactionsByDate(DateTime selectedDate)
    {
        return _transferBL.GetTransferTransactionsData(selectedDate);
    }

    #endregion
}
