﻿using Football.DAL;
using System.Collections.Generic;
using System.ServiceModel;


[ServiceContract]
public interface IPlayersService
{
    [OperationContract]
    List<PlayerCard> GetAllPlayers();

    [OperationContract]
    List<PlayerCard> GetPlayersByTeam(string team);

    [OperationContract]
    Response UpdatePlayer(PlayerCard player);

    [OperationContract]
    void ActivatePlayer(PlayerCard player);

    [OperationContract]
    void RetirePlayer(PlayerCard player);

    [OperationContract]
    void ReleasePlayer(PlayerCard player);

    [OperationContract]
    void CreateNewPlayer(PlayerCard player);

    [OperationContract]
    void FillPlayerStatuses();
}
