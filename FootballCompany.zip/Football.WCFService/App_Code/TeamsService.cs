﻿using Football.DAL;
using FootballBL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text.RegularExpressions;

public class TeamsService : ITeamsService
{
    #region Fields

    private TeamsBL _teamsBL;

    #endregion

    #region Constructor

    public TeamsService()
    {
        _teamsBL = new TeamsBL();
    }

    #endregion

    #region Public methods

    public TeamCard CheckTeamCredentials(string email, string password)
    {
        return _teamsBL.CheckTeamCredentials(email, password);
    }

    public Response AddNewTeam(TeamCard team)
    {
        Response response = new Response();
        response = ValidatePassword(team, response);
        if ( response.ErrorCode > 0 )
        {
            return response;
        }
        _teamsBL.AddNewTeam(team);
        return response;
    }

    public void DeleteTeam(TeamCard team)
    {
        _teamsBL.DeleteTeam(team);
    }    

    public Response UpdateTeam(TeamCard team)
    {
        Response response = new Response();
        response = ValidatePassword(team, response);
        if (response.ErrorCode > 0)
        {
            return response;
        }

        response = _teamsBL.UpdateTeam(team);
        return response;
    }

    private Response ValidatePassword(TeamCard team, Response response)
    {
        if (team.Password != null)
        {
            if (team.Password.Length < 8)
            {
                response.ErrorCode = 1;
                response.ErrorMessage = "The password must be at least 8 characters !";
                return response;
            }
            bool hasUppercase = !team.Password.Equals(team.Password.ToLower());
            if (!hasUppercase)
            {
                response.ErrorCode = 2;
                response.ErrorMessage = "The password must include one capital letter !";
                return response;
            }
            //string pattern = @"(\D *\d){ 1,}";      //only one digit
            string pattern = @"(?=.*\d)";
            Match result = Regex.Match(team.Password, pattern);
            if (!result.Success)
            {
                response.ErrorCode = 3;
                response.ErrorMessage = "The password must include one digit !";
                return response;
            }
            if (team.Password.All(Char.IsLetterOrDigit))
            {
                response.ErrorCode = 3;
                response.ErrorMessage = "The password must include one non-alphanumeric char !";
                return response;
            }
        }
        else
        {
            response.ErrorCode = 4;
            response.ErrorMessage = "The password is required field !";
            return response;
        }
        return response;
    }

    public List<TeamCard> GetAllTeams()
    {
        return _teamsBL.GetAllTeams();
    }

    #endregion
}
