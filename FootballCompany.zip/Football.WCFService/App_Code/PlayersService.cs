﻿using Football.DAL;
using FootballBL;
using System;
using System.Collections.Generic;
using System.Linq;

public class PlayersService : IPlayersService
{
    #region Fields

    private PlayersBL _playersBl;
    private TransferTransactionsBL _transferBL;


    #endregion

    #region Constructors

    public PlayersService()
    {
        _playersBl = new PlayersBL();
        _transferBL = new TransferTransactionsBL();
    }

    #endregion

    #region Public methods

    public List<PlayerCard> GetPlayersByTeam(string team)
    {
        List<PlayerCard> lstCards = _playersBl.GetPlayersByTeam(team);
        return lstCards;
    }

    public List<PlayerCard> GetAllPlayers()
    {
        return _playersBl.GetPlayerCards();
    }

    public Response UpdatePlayer(PlayerCard player)
    {
        return _playersBl.UpdatePlayer(player);
    }

    public void RetirePlayer(PlayerCard player)
    {
        _playersBl.RetirePlayer(player);

        TransferTransaction transaction = new TransferTransaction();
        transaction.ParentTeam = player.PreviousTeam;
        transaction.TargetTeam = player.CurrentTeam;
        transaction.TransferValue = (int)PlayerStatusEnum.Retired;
        transaction.PlayerId = player.PlayerId;
        transaction.TransferDate = DateTime.Now;
        _transferBL.AddTransferTransaction(transaction);
    }

    public void CreateNewPlayer(PlayerCard player)
    {
        _playersBl.CreateNewPlayer(player);   
    }

    public void FillPlayerStatuses()
    {
        _playersBl.FillPlayerStatuses();
    }

    public void ReleasePlayer(PlayerCard player)
    {
        _playersBl.ReleasePlayer(player);

        TransferTransaction transaction = new TransferTransaction();
        transaction.ParentTeam = player.PreviousTeam;
        transaction.TargetTeam = player.CurrentTeam;
        transaction.TransferValue = (int)PlayerStatusEnum.Released;
        transaction.PlayerId = player.PlayerId;
        transaction.TransferDate = DateTime.Now;
        _transferBL.AddTransferTransaction(transaction);
    }

    public void ActivatePlayer(PlayerCard player)
    {
        _playersBl.ActivatePlayer(player);
    }

    #endregion
}
