﻿using Football.DAL;
using FootballBL;
using System.Configuration;

public class AccountService : IAccountService
{
    #region Fields

    public TeamsBL _teamsBl;

    #endregion

    #region Constructors

    public AccountService()
    {
        _teamsBl = new TeamsBL();
    }

    #endregion

    #region Public methods

    public TeamCard LogOn(string email, string password)
    {
        TeamCard card = _teamsBl.Login(email, password);
        return card;
    }

    #endregion
}
