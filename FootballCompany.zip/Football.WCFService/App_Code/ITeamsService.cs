﻿using Football.DAL;
using System.Collections.Generic;
using System.ServiceModel;


[ServiceContract]
public interface ITeamsService
{
    [OperationContract]
    Response AddNewTeam(TeamCard team);

    [OperationContract]
    List<TeamCard> GetAllTeams();

    [OperationContract]
    void DeleteTeam(TeamCard team);

    [OperationContract]
    Response UpdateTeam(TeamCard team);

    [OperationContract]
    TeamCard CheckTeamCredentials(string email, string password);
}
