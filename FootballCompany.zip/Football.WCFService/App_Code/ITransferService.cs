﻿using Football.DAL;
using System;
using System.Collections.Generic;
using System.ServiceModel;


[ServiceContract]
public interface ITransferService
{
    [OperationContract]
    List<TransferTransaction> GetAllTransferTransactions();

    [OperationContract]
    List<TransferState> GetAllTransferStates();

    [OperationContract]
    void AddTransferTransaction(TransferTransaction trans);

    [OperationContract]
    void FillTransferState();

    [OperationContract]
    List<TransferPlayersDetails> GetTransferTransactionsByTeam(string teamName);

    [OperationContract]
    List<TransferPlayersDetails> GetTransferTransactionsByDate(DateTime selectedDate);
}
