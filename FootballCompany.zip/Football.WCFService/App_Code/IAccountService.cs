﻿using Football.DAL;
using System.ServiceModel;



[ServiceContract]
public interface IAccountService
{
    [OperationContract]
    TeamCard LogOn(string email, string password);
}
