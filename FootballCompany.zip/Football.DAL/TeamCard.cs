﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Football.DAL
{
    [Serializable]
    public class TeamCard
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TeamId { get; set; }

        public Guid TeamGuid { get; set; }

        [Required]
        public string TeamName { get; set; }

        public string MainColor { get; set; }

        public string SecondaryColor { get; set; }

        public string TeamLogoName { get; set; }

        public string TeamCity { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Please enter valid integer number for TeamSquad")]
        public string TeamSquad { get; set; }

        [Range(0, 9999999999999999.99, ErrorMessage = "Please enter valid decimal number for TeamBudget")]
        public decimal TeamBudget { get; set; }

        [Required]
        public string TeamManagerEmail { get; set; }

        //[RegularExpression(@"^(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$", ErrorMessage = "Invalid Password")]
        //[Required, MinLength(8)]
        [Required]
        public string Password { get; set; }

    }
}
