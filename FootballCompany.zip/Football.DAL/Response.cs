﻿

using System;

namespace Football.DAL
{
    [Serializable]
    public class Response
    {
        public int ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        
        public object Result { get; set; }
    }
}
