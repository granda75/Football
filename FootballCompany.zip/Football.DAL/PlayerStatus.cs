﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Football.DAL
{
    [Serializable]
    public class PlayerStatus
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }             //active -1, release to free - 2 or retire players -3.

        public string Name { get; set; }
    }
}
