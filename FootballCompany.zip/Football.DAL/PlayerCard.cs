﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace Football.DAL
{
    [Serializable]
    public class PlayerCard
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PlayerId { get; set; }

        public Guid PlayerGUID { get; set; }
         
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }
            
        public string Position { get; set; }

        [Range(0, 9999999999999999.99, ErrorMessage = "Please enter valid decimal number for Marketing Value")]
        public decimal MarketingValue { get; set; }

        [Required]
        public string CurrentTeam { get; set; }

        [Required]
        public string PreviousTeam { get; set; }

        public int LastTransferTransaction { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Please enter valid integer number for Players Status")]
        public int PlayerStatus { get; set; }

        [NotMapped]
        public string PlayerStatusName { get; set; }

        public ICollection<TransferTransaction> TransferTransactions { get; set; }
      
    }
}
