﻿
namespace Football.DAL
{
    public enum PlayerStatusEnum
    {
        Active = 1,
        Released = 2, 
        Retired = 3
    }
}
