﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace Football.DAL
{
    [Serializable]
    public class TransferTransaction
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int TransferId { get; set; }

        [ForeignKey("PlayerCard")]
        public int PlayerId { get; set; }
        
        [ForeignKey("TransferState")]
        public int TransferValue { get; set; }          // We should be able transfer -1, release to free - 2, or retire players - 3

        public string ParentTeam { get; set; }

        public string TargetTeam { get; set; }
        
        public DateTime TransferDate { get; set; }

        [IgnoreDataMember]
        public PlayerCard PlayerCard { get; set; }

        [IgnoreDataMember]
        public TransferState TransferState { get; set; }

    }
}
