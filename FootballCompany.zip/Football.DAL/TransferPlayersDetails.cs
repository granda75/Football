﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Football.DAL
{
    public class TransferPlayersDetails
    {
        public int PlayerId { get; set; }

        public Guid PlayerGUID { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int TransferId { get; set; }

        public string ParentTeam { get; set; }

        public string TargetTeam { get; set; }

        //We should be able transfer -1, release to free - 2, or retire players - 3
        public int TransferValue { get; set; }

        public string TransferDescription { get; set; }

        public DateTime TransferDate { get; set; }
    }
}
