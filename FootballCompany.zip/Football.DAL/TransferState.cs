﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Football.DAL
{
    [Serializable]
    public class TransferState
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }             //transfer, release to free or retire players.

        public string Name { get; set; }
    }
}
