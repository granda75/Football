﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;


namespace Football.DAL.Repository
{
    public class PlayersRepository : BaseRepository
    {
        #region Fields

        private FootballDBContext _context;

        #endregion

        #region Constructor

        public PlayersRepository()
        {

        }

        #endregion

        #region Players methods

        public void FillPlayerStatuses()
        {
            using (_context = new FootballDBContext())
            {
                PlayerStatus status = new PlayerStatus();
                status.Id = (int)PlayerStatusEnum.Active;
                status.Name = PlayerStatusEnum.Active.ToString();
                _context.PlayerStatuses.Add(status);

                status = new PlayerStatus();
                status.Id = (int)PlayerStatusEnum.Released;
                status.Name = PlayerStatusEnum.Released.ToString();
                _context.PlayerStatuses.Add(status);

                status = new PlayerStatus();
                status.Id = (int)PlayerStatusEnum.Retired;
                status.Name = PlayerStatusEnum.Retired.ToString();
                _context.PlayerStatuses.Add(status);

                _context.SaveChanges();
            }
        }

        public Response UpdatePlayer(PlayerCard player)
        {
            Response response = new Response();
            using (_context = new FootballDBContext())
            {
                try 
                { 
                    var foundPlayer = _context.PlayerCards.SingleOrDefault(l => l.PlayerGUID == player.PlayerGUID);
                    _context.Entry(foundPlayer).CurrentValues.SetValues(player);
                    _context.SaveChanges();
                }//try
                catch (DbEntityValidationException e)
                {
                    response.ErrorMessage = "Update not succeded ! ";
                    foreach (var eve in e.EntityValidationErrors)
                    {
                        foreach (var ve in eve.ValidationErrors)
                        {
                            response.ErrorMessage += ve.ErrorMessage + " .";
                        }
                    }//foreach
                }//catch
            }//using

            return response;
        }

        public List<PlayerCard> GetPlayersByTeam(string team)
        {
            List<PlayerCard> players = null;

            using (_context = new FootballDBContext())
            {
                players = _context.PlayerCards.Where(l => l.CurrentTeam == team).Select(l => l).ToList<PlayerCard>();
                if ( players != null )
                {
                        foreach (PlayerCard item in players)
                        {
                            item.PlayerStatusName = ((PlayerStatusEnum)item.PlayerStatus).ToString();
                        }
                }
            }

            return players;
        }

        public void UpdatePlayersTeam(TransferTransaction trans)
        {
            using (_context = new FootballDBContext())
            {
                var foundPlayer = _context.PlayerCards.SingleOrDefault(l => l.PlayerId == trans.PlayerId);
                if (foundPlayer != null)
                {
                    foundPlayer.CurrentTeam = trans.TargetTeam;
                }
                _context.SaveChanges();
            }
        }

        public void ActivatePlayer(PlayerCard player)
        {
            using (_context = new FootballDBContext())
            {
                var foundPlayer = _context.PlayerCards.SingleOrDefault(l => l.PlayerId == player.PlayerId);
                if (foundPlayer != null)
                {
                    foundPlayer.PlayerStatus = (int)PlayerStatusEnum.Active;
                }
                _context.SaveChanges();
            }
        }

        public void ReleasePlayer(PlayerCard player)
        {
            using (_context = new FootballDBContext())
            {
                var foundPlayer = _context.PlayerCards.SingleOrDefault(l => l.PlayerId == player.PlayerId);
                if (foundPlayer != null)
                {
                    foundPlayer.PlayerStatus = (int)PlayerStatusEnum.Released;
                }
                _context.SaveChanges();
            }
        }

        public void RetirePlayer(PlayerCard player)
        {
            using (_context = new FootballDBContext())
            {
                var foundPlayer = _context.PlayerCards.SingleOrDefault(l => l.PlayerId == player.PlayerId);
                if (foundPlayer != null)
                {
                    foundPlayer.PlayerStatus = (int)PlayerStatusEnum.Retired;
                }
                _context.SaveChanges();
            }
        }

        public void CreateNewPlayer(PlayerCard player)
        {
            using (_context = new FootballDBContext())
            {
                _context.PlayerCards.Add(player);
                _context.SaveChanges();
            }
        }

        public List<PlayerCard> GetAllPlayers()
        {
            using (_context = new FootballDBContext())
            {
                return _context.PlayerCards.ToList<PlayerCard>();
            }
        }

        #endregion
    }
}
