﻿using AutoMapper;

namespace Football.DAL.Repository
{
    public class BaseRepository
    {
        #region Fields

        private MapperConfiguration _mapperConfiguration;
        protected IMapper _iMapper;

        #endregion

        #region Constructor

        public BaseRepository()
        {
            _mapperConfiguration = new MapperConfiguration(cfg => {
                cfg.CreateMap<PlayerCard, PlayerCard>();
            });
            
            _iMapper = _mapperConfiguration.CreateMapper();
        
        }

        #endregion
    }
}
    