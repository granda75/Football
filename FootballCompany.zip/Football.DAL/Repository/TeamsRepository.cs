﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Linq.Expressions;

namespace Football.DAL.Repository
{
    public class TeamsRepository
    {
        #region Fields

        private FootballDBContext _context;

        #endregion

        #region Constructor

        public TeamsRepository()
        {
            
        }

        #endregion
       
        #region Team methods

        public TeamCard Login(string email, string password)
        {
            TeamCard team;
            using (_context = new FootballDBContext())
            {
                 team = _context.TeamCards.Where(l => l.TeamManagerEmail == email && l.Password == password).Select(l => l).FirstOrDefault();
            }
            return team;
        }

        public TeamCard CheckTeamCredentials(string email, string password)
        {
            TeamCard card;
            using (_context = new FootballDBContext())
            {
                card = (TeamCard)_context.TeamCards.Where(l => l.TeamManagerEmail == email && l.Password == password).Select(l => l).FirstOrDefault();
            }
            return card;
        }

        public List<TeamCard> GetAllTeams()
        { 
            using (_context = new FootballDBContext())
            {
                return _context.TeamCards.ToList<TeamCard>();
            }
        }

        public void AddNewTeam(TeamCard team)
        {
            using (_context = new FootballDBContext())
            { 
                _context.TeamCards.Add(team);
                _context.SaveChanges();
            }
        }

        public void DeleteTeam(TeamCard team)
        {
            using (_context = new FootballDBContext())
            {
                var foundTeam = _context.TeamCards.SingleOrDefault(l => l.TeamGuid == team.TeamGuid);
                if (foundTeam != null)
                {
                    _context.TeamCards.Remove(foundTeam);
                }
                
                _context.SaveChanges();
            }
        }

        public Response UpdateTeam(TeamCard team)
        {
            Response response = new Response();
            using (_context = new FootballDBContext())
            {
                try
                { 
                    var foundedTeam = _context.TeamCards.SingleOrDefault(l => l.TeamGuid == team.TeamGuid);
                    if (foundedTeam != null)
                    {
                        _context.Entry(foundedTeam).CurrentValues.SetValues(team);
                    }
                    _context.SaveChanges();
                }//try
                catch (DbEntityValidationException e)
                {
                    response.ErrorMessage = "Update not succeded ! ";
                    foreach (var eve in e.EntityValidationErrors)
                    {
                        foreach (var ve in eve.ValidationErrors)
                        {
                            response.ErrorMessage += ve.ErrorMessage + " .";
                        }
                    }//foreach
                }//catch
            }//using
            return response;
        }

        #endregion

    }
}
