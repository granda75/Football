﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Football.DAL.Repository
{
    public class TransferTransactionRepository
    {
        #region Fields

        private FootballDBContext _context;

        #endregion

        #region Constructor

        public TransferTransactionRepository()
        {
            
        }

        #endregion

        #region Public methods

        public IEnumerable<TransferPlayersDetails> GetTransferTransactionsData()
        {
            IEnumerable<TransferPlayersDetails> result;
            using (_context = new FootballDBContext())
            {

                result = (IEnumerable<TransferPlayersDetails>)_context.TransferTransactions
                        .Include("PlayerCard")
                        .Include("TransferState")
                        .Select(item => new TransferPlayersDetails
                        {
                            PlayerId = item.PlayerId,
                            FirstName = item.PlayerCard.FirstName,
                            LastName = item.PlayerCard.LastName,
                            PlayerGUID = item.PlayerCard.PlayerGUID,
                            ParentTeam = item.ParentTeam,
                            TargetTeam = item.TargetTeam,
                            TransferId = item.TransferId,
                            TransferDate = item.TransferDate,
                            TransferValue = item.TransferValue,
                            TransferDescription = item.TransferState.Name

                        }).ToList();
                        //.Where(p => p.TransferDate.Date == selectedDate.Date).ToList();
            }//using              

            return result;

        }

        public IEnumerable<TransferPlayersDetails> GetTransferTransactionsData(string teamName)
        {
            IEnumerable<TransferPlayersDetails> result;
            using (_context = new FootballDBContext())
            {

                result = (IEnumerable<TransferPlayersDetails>)_context.TransferTransactions
                        .Include("PlayerCard")
                        .Include("TransferState")
                        .Select(item => new TransferPlayersDetails
                        {
                            PlayerId  = item.PlayerId,
                            FirstName = item.PlayerCard.FirstName,
                            LastName = item.PlayerCard.LastName,
                            PlayerGUID = item.PlayerCard.PlayerGUID,
                            ParentTeam = item.ParentTeam,
                            TargetTeam = item.TargetTeam,
                            TransferId = item.TransferId,
                            TransferDate = item.TransferDate,
                            TransferValue = item.TransferValue,
                            TransferDescription = item.TransferState.Name

                        })
                        .Where(p => p.TargetTeam == teamName).ToList();
            }//using              

            return result;

        }

        public void FillTransferState()
        {
            //transfer, release to free or retire players.
            using (_context = new FootballDBContext())
            {
                TransferState state = new TransferState();
                state.Id = 1;
                state.Name = "transfer";
                _context.TransferStates.Add(state);

                state = new TransferState();
                state.Id = 2;
                state.Name = "release";
                _context.TransferStates.Add(state);

                state = new TransferState();
                state.Id = 3;
                state.Name = "retire";
                _context.TransferStates.Add(state);

                _context.SaveChanges();
            }

        }

        public void GetTransactionsByTeam(string teamName)
        {
            using (_context = new FootballDBContext())
            {
                var transactions = _context.TransferTransactions.Include("PlayerCard").Where(l=>l.TargetTeam == teamName).ToList();

            }
        }

        public void AddTransferTransaction(TransferTransaction trans)
        {
            using (_context = new FootballDBContext())
            {
                _context.TransferTransactions.Add(trans);
                _context.SaveChanges();
            }
        }

        public List<TransferTransaction> GetAllTransferTransactions()
        {
            using (_context = new FootballDBContext())
            {
                return _context.TransferTransactions.ToList<TransferTransaction>();
            }
        }

        public List<TransferState> GetAllTransferStates()
        {
            using (_context = new FootballDBContext())
            {
                return _context.TransferStates.ToList<TransferState>();
            }
        }

        #endregion

    }
}
