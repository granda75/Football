﻿using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace Football.DAL
{
    public class FootballDBContext : DbContext
    {
        #region Constructor
        
        public FootballDBContext() : base()
        {
           Database.SetInitializer<FootballDBContext>(null);
           // Database.SetInitializer<FootballDBContext>(new CreateDatabaseIfNotExists<FootballDBContext>());
        }

        #endregion

        #region Properties

        public DbSet<PlayerCard> PlayerCards { get; set; }
        public DbSet<TeamCard> TeamCards { get; set; }
        public DbSet<TransferTransaction> TransferTransactions { get; set; }
        public DbSet<TransferState> TransferStates { get; set; }

        public DbSet<PlayerStatus> PlayerStatuses { get; set; }

        #endregion

        #region Methods

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

        #endregion
    }
}
