﻿namespace Football.DAL
{

    public class DatabaseBootstrapper
    {
        #region Fields

        private readonly FootballDBContext context;

        public DatabaseBootstrapper(FootballDBContext context)
        {
            this.context = context;
        }

        #endregion

        #region Public methods

        public void Configure()
        {
            if (context.Database.Exists())
            {
                return;
            }
                
            context.Database.Create();
           
        }

        #endregion
    }
}
